package com.example.cs360proj;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class LoginActivity extends AppCompatActivity {
    EditText username, password;
    Button LoginButton;
    DatabaseLogin DB;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = findViewById(R.id.username1);
        password = findViewById(R.id.password1);
        LoginButton = findViewById(R.id.login1);
        DB = new DatabaseLogin(this);

        // allows login button to move views
        LoginButton.setOnClickListener(view -> {

            String Username = username.getText().toString();
            String Password = password.getText().toString();

            Boolean ValidatePassword = DB.verifyLoginCred(Username, Password);
            if(ValidatePassword) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
            }else{
                Toast.makeText(LoginActivity.this, "Login Error", Toast.LENGTH_SHORT).show();
            }

        });
    }
}

