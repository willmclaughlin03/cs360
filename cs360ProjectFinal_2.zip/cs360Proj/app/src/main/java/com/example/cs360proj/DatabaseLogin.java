package com.example.cs360proj;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DatabaseLogin extends SQLiteOpenHelper {
    public DatabaseLogin(Context context) {
        super(context, "Login.db", null, 1);
    }

    @Override    // creates table
    public void onCreate(SQLiteDatabase MyDB) {
        MyDB.execSQL("create Table users(username TEXT primary key, password TEXT)");
    }

    @Override    // uses DB for table
    public void onUpgrade(SQLiteDatabase MyDB, int i, int i1) {
        MyDB.execSQL("drop Table if exists users");
    }

    public Boolean AddData(String username, String password){
        SQLiteDatabase MyDB = this.getWritableDatabase();
        ContentValues contentValues= new ContentValues();   // add data function
        contentValues.put("username", username);
        contentValues.put("password", password);
        long result = MyDB.insert("users", null, contentValues);
        return result != -1;
    }

    public Boolean verifyLoginCred(String username, String password){  // verifies credentials login
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ? and password = ?", new String[] {username,password});
        boolean result = cursor.getCount() > 0;
        cursor.close(); // Close the Cursor
        return result;
    }
    public Boolean verifyCred(String username) {   // verifies credentials user
        SQLiteDatabase MyDB = this.getWritableDatabase();
        Cursor cursor = MyDB.rawQuery("Select * from users where username = ?", new String[]{username});
        boolean result = cursor.getCount() > 0;
        cursor.close();
        return result;
    }


}

