package com.example.cs360proj;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;



public class MainActivity extends AppCompatActivity {

    EditText dateEditText, weightEditText, goalWeightEditText;
    ListView logListView;
    Button notifyButton, changeButton, deleteButton;

    Button addButton;
    // instantiate
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        addButton = findViewById(R.id.add_data);
        changeButton = findViewById(R.id.change);
        deleteButton = findViewById(R.id.remove);
        notifyButton = findViewById(R.id.Notify);
        dateEditText = findViewById(R.id.editTextDate);
        weightEditText = findViewById(R.id.weight);
        goalWeightEditText = findViewById(R.id.goalWeight);
        logListView = findViewById(R.id.weight_list);

        try (DatabaseController databaseController = new DatabaseController(MainActivity.this)) {
            List<ModelView> everyone = databaseController.GetAll();
            ArrayAdapter<ModelView> userArrayAdapter = new ArrayAdapter<>(MainActivity.this, android.R.layout.simple_list_item_1, everyone);
            logListView.setAdapter(userArrayAdapter);
        }


        // allows changes and send pop up when completion or error
        addButton.setOnClickListener(view -> {
            ModelView viewModel;
            try {
                viewModel = new ModelView(-1,
                        dateEditText.getText().toString(),
                        Integer.parseInt(weightEditText.getText().toString()),
                        Integer.parseInt(goalWeightEditText.getText().toString()));
                Toast.makeText(MainActivity.this, viewModel.toString(), Toast.LENGTH_SHORT).show();

                try (DatabaseController databaseController12 = new DatabaseController(MainActivity.this)) {
                    boolean success = databaseController12.Add(viewModel);
                    Toast.makeText(MainActivity.this, "Complete = " + success, Toast.LENGTH_SHORT).show();

                    // Update the adapter
                    ArrayAdapter<ModelView> userArrayAdapter = (ArrayAdapter<ModelView>) logListView.getAdapter();
                    databaseController12.updateAdapter(userArrayAdapter);
                }
            } catch (Exception e) {
                viewModel = new ModelView(-1, "Error", 0, 0);
            }
        });


// allows for deletion and sends confirmation
        deleteButton.setOnClickListener(view -> {
            ModelView viewModel;
            try {
                viewModel = new ModelView(-1,
                        dateEditText.getText().toString(),
                        Integer.parseInt(weightEditText.getText().toString()));

                Toast.makeText(MainActivity.this, viewModel.toString(), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                viewModel = new ModelView(-1, "Error", 0);
            }

            try (DatabaseController databaseController1 = new DatabaseController(MainActivity.this)) {
                boolean complete = databaseController1.Remove(viewModel);
            }
        });
// sets the current weights and goal weights as well as updates them and the user
        notifyButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), SMS.class);
            startActivity(intent);
            Toast.makeText(MainActivity.this, "Notify", Toast.LENGTH_SHORT).show();
        });




    }
    private double getCurrentWeightFromDatabase() {
        return 0.0;
    }
    private double getGoalWeightFromDatabase() {
        return 0.0;
    }
}