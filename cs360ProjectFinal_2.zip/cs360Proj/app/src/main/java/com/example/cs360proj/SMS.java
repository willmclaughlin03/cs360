package com.example.cs360proj;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;

import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.widget.SwitchCompat;

public class SMS extends AppCompatActivity {

    private static final int REQUEST_SMS_PERMISSION = 1;

    private SwitchCompat switchNotification;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        switchNotification = findViewById(R.id.switch1);
// allows for SMS
        switchNotification.setOnCheckedChangeListener((buttonView, isChecked) -> {
            if (isChecked) {
                // If the switch is checked, proceed with sending SMS
                if (checkSmsPermission()) {
                    sendSmsMessage();
                } else {
                    requestSmsPermission();
                }
            }
        });
    }
// checks permission
    private boolean checkSmsPermission() {

        return ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestSmsPermission() {

        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, REQUEST_SMS_PERMISSION);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SMS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                sendSmsMessage();
            } else {
                // Permission denied
                Toast.makeText(this, "SMS permission denied. SMS functionality disabled.", Toast.LENGTH_SHORT).show();

                switchNotification.setChecked(false);
            }
        }
    }
// sends the actual sms as well as has message display for users
    private void sendSmsMessage() {
        DatabaseController databaseController = new DatabaseController(this);
        double currentWeight = databaseController.getCurrentWeight();
        double goalWeight = databaseController.getGoalWeight();

        if (currentWeight <= goalWeight) {
            String phoneNumber = "123456789";
            String message = "Congratulations! You've reached your goal weight.";

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "SMS sent successfully!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Goal weight not reached yet!", Toast.LENGTH_SHORT).show();
        }
}}
