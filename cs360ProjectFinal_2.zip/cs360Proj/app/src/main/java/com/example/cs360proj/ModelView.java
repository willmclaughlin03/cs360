package com.example.cs360proj;

import androidx.annotation.NonNull;

// overall handling of variables throughout the project
public class ModelView {

    private int id;
    private String date;
    private int weight;

    private int goalWeight;

    public ModelView(int id, String date, int weight) {
    }

    public int getId() {

        return id;
    }

    public void setId(int id) {

        this.id = id;
    }

    public String getDate() {

        return date;
    }

    public void setDate(String date) {

        this.date = date;
    }

    public int getWeight() {

        return weight;
    }

    public void setWeight(int weight) {

        this.weight = weight;
    }

    public void setGoalWeight(int goalWeight) {
        this.goalWeight = goalWeight;
    }




    public ModelView(int id, String date, int weight, int goalWeight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
        this.goalWeight = goalWeight;
    }

    @NonNull
    @Override
    public String toString() {
        return date + ' ' + weight + ' ' + goalWeight;
    }



}
