package com.example.cs360proj;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.ArrayAdapter;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class DatabaseController extends SQLiteOpenHelper {
// DB values
    public static final String WEIGHT_TABLE = "WEIGHT_TABLE";
    public static final String COLUMN_USER_DATE = "USER_DATE";
    public static final String COLUMN_USER_WEIGHT = "USER_WEIGHT";

    public static final String COLUMN_GOAL_WEIGHT = "GOAL_WEIGHT";
    public static final String COLUMN_ID = "ID";

    public DatabaseController(@Nullable Context context) {
        super(context, "weight_log.db", null, 1);
    }

    // Create DB
    @Override
    public void onCreate(SQLiteDatabase db) {

        String createTableStatement = "CREATE TABLE " + WEIGHT_TABLE + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USER_DATE + " TEXT, " + COLUMN_USER_WEIGHT + " INTEGER, " + COLUMN_GOAL_WEIGHT + " REAL)";

        db.execSQL(createTableStatement);
    }


    //do changes
    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {

    }
// Allows for adding to DB
    public boolean Add(ModelView viewModel) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues cv = new ContentValues();

        cv.put(COLUMN_USER_DATE, viewModel.getDate());
        cv.put(COLUMN_USER_WEIGHT, viewModel.getWeight());

        long insert = db.insert(WEIGHT_TABLE, null, cv);
        return insert != -1;
    }


// first step to retrieve all
public List<ModelView> GetAll() {
    List<ModelView> returnList = new ArrayList<>();

    try (SQLiteDatabase db = this.getReadableDatabase();
         Cursor cursor = db.rawQuery("SELECT * FROM " + WEIGHT_TABLE, null)) {

        if (cursor.moveToFirst()) {
            do {
                int idNum = cursor.getInt(0);
                String userDate = cursor.getString(1);
                int userWeight = cursor.getInt(2);

                ModelView newEntry = new ModelView(idNum, userDate, userWeight);
                returnList.add(newEntry);

            } while (cursor.moveToNext());
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return returnList;
}
// removes
    public boolean Remove(ModelView viewModel) {

        SQLiteDatabase db = this.getWritableDatabase();


        String whereClause = COLUMN_USER_DATE + " = ? AND " + COLUMN_USER_WEIGHT + " = ?";


        String[] whereArgs = {viewModel.getDate(), String.valueOf(viewModel.getWeight())};

        // Perform the deletion
        int deletedRows = db.delete(WEIGHT_TABLE, whereClause, whereArgs);

        // Check if any rows were deleted
        return deletedRows > 0;
    }


    // gets the current weight from DB
    public double getCurrentWeight() {
        double currentWeight = 0.0;

        try (SQLiteDatabase db = this.getReadableDatabase();
             Cursor cursor = db.rawQuery("SELECT MAX(" + COLUMN_USER_WEIGHT + ") FROM " + WEIGHT_TABLE, null)) {

            if (cursor.moveToFirst()) {
                currentWeight = cursor.getDouble(0);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return currentWeight;
    }
// gets goal weight from DB
    public double getGoalWeight() {
        double goalWeight = 0.0;

        try (SQLiteDatabase db = this.getReadableDatabase();
             Cursor cursor = db.rawQuery("SELECT MAX(" + COLUMN_GOAL_WEIGHT + ") FROM " + WEIGHT_TABLE, null)) {

            if (cursor.moveToFirst()) {
                goalWeight = cursor.getDouble(0);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return goalWeight;
    }

    public void updateAdapter(ArrayAdapter<ModelView> adapter) {
        List<ModelView> newData = GetAll();
        adapter.clear();
        adapter.addAll(newData);
        adapter.notifyDataSetChanged();
    }
}